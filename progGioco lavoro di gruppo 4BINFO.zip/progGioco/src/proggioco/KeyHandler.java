package proggioco;

import java.awt.event.*;

class KeyHandler implements KeyListener{
    
    public boolean left, right, pause = false;

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if(code == KeyEvent.VK_A || code == KeyEvent.VK_LEFT) {
            left = true;
        }
        if(code == KeyEvent.VK_D || code == KeyEvent.VK_RIGHT) {
            right = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if(code == KeyEvent.VK_ESCAPE || code == KeyEvent.VK_P) {
            if(!pause) {
               pause = true; 
            } else if(pause) {
                pause = false;
            }
        }
        if(code == KeyEvent.VK_A || code == KeyEvent.VK_LEFT) {
            left = false;
        }
        if(code == KeyEvent.VK_D || code == KeyEvent.VK_RIGHT) {
            right = false;
        }
    }
    
    public boolean getPause() {
        return pause;
    }
    
    public void setPause(boolean pause) {
        this.pause = pause;
    }
}
