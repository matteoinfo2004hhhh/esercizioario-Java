package proggioco;

import java.awt.*;
import java.io.IOException;
import javax.imageio.*;
import javax.swing.*;

public class Character extends JPanel {

    public Image image;

    Character (boolean right) {
        if (right) {
            try {
                image = ImageIO.read(getClass().getResource("/resources/orsoRight.png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                image = ImageIO.read(getClass().getResource("/resources/orsoLeft.png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void paintComponent(Graphics g, int x, int y) {
        super.paintComponent(g);
        if (image != null) {
            g.drawImage(image, x, y, 130, 130, null);
        }
    }
}
