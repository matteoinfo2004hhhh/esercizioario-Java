package proggioco;

import java.awt.*;
import java.io.IOException;
import javax.swing.*;

public class GUIGioco extends JPanel implements Runnable {

    private KeyHandler keyH;
    private int x = 0;
    private int y = 740 - 100;
    private int playerSpeed = 10;
    Character character;
    Images commands;
    boolean right = true;
    Label b = new Label();
    Graphics g;
    int rand = 0;
    int imgPosX, imgPosY = -100;

    Thread gameThread;

    GUIGioco() {
        keyH = new KeyHandler();
        rand = (int) (Math.random() * 9);
        imgPosX = (int) (Math.random() * (800 - 185)) + 200;
        this.add(b);
        this.setLayout(null);
        this.setBounds(0, 0, 1200, 800);
        this.setBackground(Color.black);
        this.setOpaque(true);
        this.addKeyListener(keyH);
        this.setFocusable(true);
        x = this.getWidth() / 2 - 50;
        startGameThread();
    }

    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {
        b.setVisible(false);
        b.setSize(660, 200);
        b.setForeground(Color.WHITE);
        b.setLocation(1200 / 2 - 330, 790 / 2 - 100);
        b.setFont(new Font("Arial", Font.PLAIN, 200));
        b.setText("PAUSE");
        while (gameThread != null) {
            update();
            repaint();
            try {
                Thread.sleep(15);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void update() {
        if (!keyH.getPause()) {
            b.setVisible(false);
            if (keyH.left && x >= 200) {
                x -= playerSpeed;
                right = false;
            } else if (keyH.right && x + 130 <= 1000) {
                x += playerSpeed;
                right = true;
            }
        } else {
            pause();
        }
        if (imgPosY <= 800 && !checkPos()) {
            imgPosY+=4;
        } else {
            rand = (int) (Math.random() * 9);
            imgPosX = (int) (Math.random() * (800 - 185)) + 200;
            imgPosY = -100;
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        character = new Character(right);
        character.paintComponent(g, x, y);
        commands = new Images(rand);
        commands.paintComponent(g, imgPosX, imgPosY);
    }

    public void pause() {
        commands.setVisible(true);
        b.setVisible(true);
    }
    
    private boolean checkPos() {
        if(imgPosX >= x && imgPosX <= x + 130 && imgPosY + 100 == y) {
            return true;
        } else {
            return false;
        }
    }    
}
