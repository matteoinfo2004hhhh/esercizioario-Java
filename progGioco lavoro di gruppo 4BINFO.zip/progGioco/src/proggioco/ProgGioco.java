package proggioco;

import java.awt.Color;
import javax.swing.JFrame;

public class ProgGioco {

    ProgGioco() {
        startWindow();
        
    }

    public static void main(String[] args) {
        new ProgGioco();
    }

    public void startWindow() {
        JFrame frame = new JFrame("Catch TCB");
        GUIGioco gioco = new GUIGioco();
        frame.setResizable(false);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(0, 0, 1200, 800);
        frame.add(gioco);
        frame.setBackground(Color.black);
        frame.setVisible(true);
    }

}
