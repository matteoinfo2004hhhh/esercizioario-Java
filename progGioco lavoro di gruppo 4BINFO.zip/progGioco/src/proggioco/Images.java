package proggioco;

import java.awt.*;
import java.io.IOException;
import javax.imageio.*;
import javax.swing.*;

public class Images extends JPanel {

    public Image image;
    
    int imgY = 100;
    int imgX = imgY / 16 * 9;

    Images(int a) {
        switch (a) {
            case 0:
                try {
                image = ImageIO.read(getClass().getResource("/resources/numbers/0.png"));
            } catch (IOException e) {

            }
            break;
            case 1:
                try {
                image = ImageIO.read(getClass().getResource("/resources/numbers/1.png"));
            } catch (IOException e) {

            }
            break;
            case 2:
                try {
                image = ImageIO.read(getClass().getResource("/resources/numbers/2.png"));
            } catch (IOException e) {

            }
            break;
            case 3:
                try {
                image = ImageIO.read(getClass().getResource("/resources/numbers/3.png"));
            } catch (IOException e) {

            }
            break;
            case 4:
                try {
                image = ImageIO.read(getClass().getResource("/resources/numbers/4.png"));
            } catch (IOException e) {

            }
            break;
            case 5:
                try {
                image = ImageIO.read(getClass().getResource("/resources/numbers/5.png"));
            } catch (IOException e) {

            }
            break;
            case 6:
                try {
                image = ImageIO.read(getClass().getResource("/resources/numbers/6.png"));
            } catch (IOException e) {

            }
            break;
            case 7:
                try {
                image = ImageIO.read(getClass().getResource("/resources/numbers/7.png"));
            } catch (IOException e) {

            }
            break;
            case 8:
                try {
                image = ImageIO.read(getClass().getResource("/resources/numbers/8.png"));
            } catch (IOException e) {

            }
            break;
            case 9:
                try {
                image = ImageIO.read(getClass().getResource("/resources/numbers/9.png"));
            } catch (IOException e) {

            }
            break;
        }
    }

    public void paintComponent(Graphics g, int x, int y) {
        super.paintComponent(g);
        if (image != null) {
            g.drawImage(image, x, y, imgX, imgY, null);
        }
    }
}
